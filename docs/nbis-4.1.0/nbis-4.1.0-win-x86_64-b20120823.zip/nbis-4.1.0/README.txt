NIST Biometric Image Software 4.1.0
===================================

IBG Build 2012-08-23
-----------------------------------

Installation for most use cases: 

Unzip to a directory of your choice, and add the bin folder to your system path.

Most programs included in this distribution work as expected, but a few were 
compiled with the installation path set to c:\ProgramData\NBIS. These few
exceptions include PCASYS and the programs that retrain NFIQ (and possibly
others). If you do need to use these out-of-the-ordinary programs, be sure
to move the nbis-4.1.0 directory to C:\ProgramData and rename it NBIS. Also,
it appears that PCASYS does not work unless in an MSYS shell. See the 
instructions in the source code release regarding how to set up a suitable
MSYS/MinGW environment.

